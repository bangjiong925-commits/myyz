// PM2 生产环境配置文件
module.exports = {
  apps: [
    {
      name: 'myyz-api',
      script: 'api_server_mongodb.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3001
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3001
      },
      log_file: './logs/api-combined.log',
      out_file: './logs/api-out.log',
      error_file: './logs/api-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      max_memory_restart: '1G'
    },
    {
      name: 'myyz-keys',
      script: 'key_management_server.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3002
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3002
      },
      log_file: './logs/keys-combined.log',
      out_file: './logs/keys-out.log',
      error_file: './logs/keys-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      max_memory_restart: '1G'
    },
    {
      name: 'myyz-aliyun-keys',
      script: './aliyun-key-server/server.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 3003
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3003
      },
      log_file: './logs/aliyun-keys-combined.log',
      out_file: './logs/aliyun-keys-out.log',
      error_file: './logs/aliyun-keys-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      max_memory_restart: '1G'
    },
    {
      name: 'myyz-proxy',
      script: 'proxy-server.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production',
        PORT: 8080
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 8080
      },
      log_file: './logs/proxy-combined.log',
      out_file: './logs/proxy-out.log',
      error_file: './logs/proxy-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      max_memory_restart: '1G'
    }
  ]
};