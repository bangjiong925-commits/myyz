#!/bin/bash

# 阿里云服务器部署脚本
# 使用方法: ./deploy-to-aliyun.sh

echo "🚀 开始部署到阿里云服务器..."

# 配置变量 - 请根据您的实际服务器信息修改
SERVER_IP="YOUR_ALIYUN_SERVER_IP"
SERVER_USER="root"
SERVER_PATH="/var/www/myyz"
PROJECT_NAME="myyz"

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查必要文件
echo -e "${YELLOW}📋 检查部署文件...${NC}"
if [ ! -f "package.json" ]; then
    echo -e "${RED}❌ 未找到 package.json 文件${NC}"
    exit 1
fi

if [ ! -f "TWPK.html" ]; then
    echo -e "${RED}❌ 未找到 TWPK.html 文件${NC}"
    exit 1
fi

# 创建部署包
echo -e "${YELLOW}📦 创建部署包...${NC}"
tar -czf ${PROJECT_NAME}-deploy.tar.gz \
    --exclude=node_modules \
    --exclude=.git \
    --exclude=logs \
    --exclude=data \
    --exclude=*.log \
    .

echo -e "${GREEN}✅ 部署包创建完成${NC}"

# 上传到服务器
echo -e "${YELLOW}📤 上传文件到阿里云服务器...${NC}"
echo "请手动执行以下命令上传文件："
echo ""
echo -e "${GREEN}scp ${PROJECT_NAME}-deploy.tar.gz ${SERVER_USER}@${SERVER_IP}:~/${NC}"
echo ""

# 服务器端执行的命令
echo -e "${YELLOW}📋 服务器端执行命令:${NC}"
cat << 'EOF'

# 1. 连接到服务器
ssh root@YOUR_ALIYUN_SERVER_IP

# 2. 创建项目目录
sudo mkdir -p /var/www/myyz
cd /var/www/myyz

# 3. 解压文件
tar -xzf ~/myyz-deploy.tar.gz

# 4. 安装依赖
npm install

# 5. 安装PM2进程管理器
npm install -g pm2

# 6. 启动服务
pm2 start ecosystem.config.js

# 7. 设置开机自启
pm2 startup
pm2 save

# 8. 配置Nginx (可选)
# sudo nano /etc/nginx/sites-available/myyz

EOF

echo -e "${GREEN}🎉 部署脚本准备完成！${NC}"
echo -e "${YELLOW}请按照上述步骤在阿里云服务器上执行命令${NC}"