/**
 * 数据库操作服务
 * 提供密钥验证记录的增删改查操作
 */

import { MongoClient } from 'mongodb';
import { KeyVerification, SystemStats, AdminLog } from '../models/KeyVerification.js';

class DatabaseService {
    constructor(mongoUri) {
        this.mongoUri = mongoUri;
        this.client = null;
        this.db = null;
        this.isConnected = false;
    }

    /**
     * 连接数据库
     */
    async connect() {
        try {
            if (this.isConnected) {
                return this.db;
            }

            this.client = new MongoClient(this.mongoUri);
            await this.client.connect();
            this.db = this.client.db();
            this.isConnected = true;
            
            console.log('数据库连接成功');
            return this.db;
        } catch (error) {
            console.error('数据库连接失败:', error);
            throw error;
        }
    }

    /**
     * 断开数据库连接
     */
    async disconnect() {
        try {
            if (this.client) {
                await this.client.close();
                this.isConnected = false;
                console.log('数据库连接已关闭');
            }
        } catch (error) {
            console.error('关闭数据库连接时出错:', error);
        }
    }

    /**
     * 获取集合
     */
    getCollection(name) {
        if (!this.db) {
            throw new Error('数据库未连接');
        }
        return this.db.collection(name);
    }

    /**
     * 验证并记录密钥使用
     */
    async verifyAndRecordKey(keyData) {
        try {
            const keyVerification = new KeyVerification(keyData);
            
            // 验证数据完整性
            const validation = keyVerification.validate();
            if (!validation.isValid) {
                throw new Error(`数据验证失败: ${validation.errors.join(', ')}`);
            }

            const collection = this.getCollection('key_verifications');
            
            // 检查密钥是否已存在
            const existingKey = await collection.findOne({ keyId: keyVerification.keyId });
            
            if (existingKey) {
                // 密钥已存在，返回已使用状态
                return {
                    success: false,
                    isValid: false,
                    message: '密钥已被使用',
                    keyId: keyVerification.keyId,
                    firstUsedAt: existingKey.verificationTime,
                    isExpired: KeyVerification.fromDocument(existingKey).isExpired()
                };
            }

            // 新密钥，插入记录
            const document = keyVerification.toDocument();
            const result = await collection.insertOne(document);
            
            // 更新统计信息
            await this.updateStats('verification', keyVerification.isValid);
            
            return {
                success: true,
                isValid: keyVerification.isValid,
                message: keyVerification.isValid ? '密钥验证成功' : '密钥验证失败',
                keyId: keyVerification.keyId,
                verificationTime: keyVerification.verificationTime,
                expiryTime: keyVerification.expiryTime,
                insertedId: result.insertedId
            };

        } catch (error) {
            console.error('验证并记录密钥时出错:', error);
            
            // 记录失败统计
            await this.updateStats('verification', false).catch(console.error);
            
            throw error;
        }
    }

    /**
     * 查询密钥状态
     */
    async getKeyStatus(keyId) {
        try {
            const collection = this.getCollection('key_verifications');
            const keyRecord = await collection.findOne({ keyId });
            
            if (!keyRecord) {
                return {
                    exists: false,
                    message: '密钥不存在'
                };
            }

            const keyVerification = KeyVerification.fromDocument(keyRecord);
            
            return {
                exists: true,
                keyId: keyVerification.keyId,
                isValid: keyVerification.isValid,
                verificationTime: keyVerification.verificationTime,
                expiryTime: keyVerification.expiryTime,
                isExpired: keyVerification.isExpired(),
                remainingTime: keyVerification.getRemainingTime(),
                deviceInfo: keyVerification.deviceInfo
            };

        } catch (error) {
            console.error('查询密钥状态时出错:', error);
            throw error;
        }
    }

    /**
     * 获取系统统计信息
     */
    async getSystemStats() {
        try {
            const collection = this.getCollection('system_stats');
            const statsDoc = await collection.findOne({ _id: 'global_stats' });
            
            if (!statsDoc) {
                // 如果统计记录不存在，创建初始记录
                const initialStats = new SystemStats();
                await collection.insertOne(initialStats.toDocument());
                return initialStats;
            }

            return SystemStats.fromDocument(statsDoc);

        } catch (error) {
            console.error('获取系统统计信息时出错:', error);
            throw error;
        }
    }

    /**
     * 更新统计信息
     */
    async updateStats(type, isSuccess = true) {
        try {
            const collection = this.getCollection('system_stats');
            const updateFields = {
                lastUpdated: new Date()
            };

            if (type === 'verification') {
                updateFields.totalVerifications = { $inc: 1 };
                if (isSuccess) {
                    updateFields.totalUniqueKeys = { $inc: 1 };
                } else {
                    updateFields.totalFailedAttempts = { $inc: 1 };
                }
            }

            await collection.updateOne(
                { _id: 'global_stats' },
                { 
                    $inc: {
                        totalVerifications: 1,
                        ...(isSuccess ? { totalUniqueKeys: 1 } : { totalFailedAttempts: 1 })
                    },
                    $set: { lastUpdated: new Date() }
                },
                { upsert: true }
            );

        } catch (error) {
            console.error('更新统计信息时出错:', error);
            // 统计更新失败不应该影响主要功能
        }
    }

    /**
     * 清理过期密钥
     */
    async cleanupExpiredKeys() {
        try {
            const collection = this.getCollection('key_verifications');
            const now = new Date();
            
            const result = await collection.deleteMany({
                expiryTime: { $lt: now }
            });

            console.log(`清理了 ${result.deletedCount} 个过期密钥`);
            return result.deletedCount;

        } catch (error) {
            console.error('清理过期密钥时出错:', error);
            throw error;
        }
    }

    /**
     * 管理员重置密钥
     */
    async adminResetKey(keyId, adminId, ipAddress, userAgent) {
        try {
            const collection = this.getCollection('key_verifications');
            
            // 删除指定密钥
            const result = await collection.deleteOne({ keyId });
            
            // 记录管理员操作日志
            await this.logAdminAction({
                action: 'reset_key',
                adminId,
                targetKeyId: keyId,
                details: { deletedCount: result.deletedCount },
                ipAddress,
                userAgent,
                result: result.deletedCount > 0 ? 'success' : 'not_found'
            });

            return {
                success: result.deletedCount > 0,
                message: result.deletedCount > 0 ? '密钥重置成功' : '密钥不存在',
                deletedCount: result.deletedCount
            };

        } catch (error) {
            console.error('管理员重置密钥时出错:', error);
            
            // 记录失败日志
            await this.logAdminAction({
                action: 'reset_key',
                adminId,
                targetKeyId: keyId,
                details: { error: error.message },
                ipAddress,
                userAgent,
                result: 'error'
            }).catch(console.error);
            
            throw error;
        }
    }

    /**
     * 记录管理员操作日志
     */
    async logAdminAction(actionData) {
        try {
            const adminLog = new AdminLog(actionData);
            
            const validation = adminLog.validate();
            if (!validation.isValid) {
                console.error('管理员日志数据验证失败:', validation.errors);
                return;
            }

            const collection = this.getCollection('admin_logs');
            await collection.insertOne(adminLog.toDocument());

        } catch (error) {
            console.error('记录管理员操作日志时出错:', error);
            // 日志记录失败不应该影响主要功能
        }
    }

    /**
     * 获取数据库健康状态
     */
    async getHealthStatus() {
        try {
            if (!this.isConnected) {
                return { status: 'disconnected', message: '数据库未连接' };
            }

            // 执行简单的ping操作
            await this.db.admin().ping();
            
            // 获取基本统计信息
            const stats = await this.getSystemStats();
            
            return {
                status: 'healthy',
                message: '数据库连接正常',
                totalVerifications: stats.totalVerifications,
                totalUniqueKeys: stats.totalUniqueKeys,
                totalFailedAttempts: stats.totalFailedAttempts,
                lastUpdated: stats.lastUpdated
            };

        } catch (error) {
            console.error('检查数据库健康状态时出错:', error);
            return {
                status: 'error',
                message: error.message
            };
        }
    }
}

export default DatabaseService;