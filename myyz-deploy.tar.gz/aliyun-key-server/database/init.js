/**
 * 阿里云密钥管理系统 - 数据库初始化脚本
 * 创建必要的集合和索引
 */

import { MongoClient } from 'mongodb';
import dotenv from 'dotenv';

dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/aliyun-key-management';

async function initializeDatabase() {
    let client;
    
    try {
        console.log('连接到MongoDB数据库...');
        client = new MongoClient(MONGODB_URI);
        await client.connect();
        
        const db = client.db();
        console.log('数据库连接成功');
        
        // 1. 创建密钥验证记录集合
        const keyVerificationCollection = 'key_verifications';
        
        // 检查集合是否存在
        const collections = await db.listCollections({ name: keyVerificationCollection }).toArray();
        if (collections.length === 0) {
            await db.createCollection(keyVerificationCollection);
            console.log(`✓ 创建集合: ${keyVerificationCollection}`);
        } else {
            console.log(`✓ 集合已存在: ${keyVerificationCollection}`);
        }
        
        // 2. 创建索引
        const keyVerifications = db.collection(keyVerificationCollection);
        
        // 为密钥ID创建唯一索引
        await keyVerifications.createIndex(
            { keyId: 1 }, 
            { unique: true, name: 'keyId_unique' }
        );
        console.log('✓ 创建索引: keyId (唯一)');
        
        // 为过期时间创建索引（用于清理过期密钥）
        await keyVerifications.createIndex(
            { expiryTime: 1 }, 
            { name: 'expiryTime_index' }
        );
        console.log('✓ 创建索引: expiryTime');
        
        // 为创建时间创建索引（用于查询和统计）
        await keyVerifications.createIndex(
            { createdAt: 1 }, 
            { name: 'createdAt_index' }
        );
        console.log('✓ 创建索引: createdAt');
        
        // 为设备信息创建索引（用于统计分析）
        await keyVerifications.createIndex(
            { 'deviceInfo.userAgent': 1 }, 
            { name: 'deviceInfo_userAgent_index' }
        );
        console.log('✓ 创建索引: deviceInfo.userAgent');
        
        // 为IP地址创建索引（用于安全分析）
        await keyVerifications.createIndex(
            { 'deviceInfo.ipAddress': 1 }, 
            { name: 'deviceInfo_ipAddress_index' }
        );
        console.log('✓ 创建索引: deviceInfo.ipAddress');
        
        // 3. 创建系统统计集合
        const systemStatsCollection = 'system_stats';
        const systemStatsCollections = await db.listCollections({ name: systemStatsCollection }).toArray();
        if (systemStatsCollections.length === 0) {
            await db.createCollection(systemStatsCollection);
            console.log(`✓ 创建集合: ${systemStatsCollection}`);
            
            // 初始化统计数据
            await db.collection(systemStatsCollection).insertOne({
                _id: 'global_stats',
                totalVerifications: 0,
                totalUniqueKeys: 0,
                totalFailedAttempts: 0,
                lastUpdated: new Date(),
                createdAt: new Date()
            });
            console.log('✓ 初始化系统统计数据');
        } else {
            console.log(`✓ 集合已存在: ${systemStatsCollection}`);
        }
        
        // 4. 创建管理员操作日志集合
        const adminLogsCollection = 'admin_logs';
        const adminLogsCollections = await db.listCollections({ name: adminLogsCollection }).toArray();
        if (adminLogsCollections.length === 0) {
            await db.createCollection(adminLogsCollection);
            console.log(`✓ 创建集合: ${adminLogsCollection}`);
        } else {
            console.log(`✓ 集合已存在: ${adminLogsCollection}`);
        }
        
        // 为管理员日志创建索引
        const adminLogs = db.collection(adminLogsCollection);
        await adminLogs.createIndex(
            { timestamp: 1 }, 
            { name: 'timestamp_index' }
        );
        console.log('✓ 创建索引: admin_logs.timestamp');
        
        await adminLogs.createIndex(
            { action: 1 }, 
            { name: 'action_index' }
        );
        console.log('✓ 创建索引: admin_logs.action');
        
        // 5. 设置TTL索引自动清理过期数据
        await keyVerifications.createIndex(
            { expiryTime: 1 }, 
            { 
                expireAfterSeconds: 0, // 在expiryTime时间点自动删除
                name: 'auto_cleanup_expired_keys' 
            }
        );
        console.log('✓ 创建TTL索引: 自动清理过期密钥');
        
        // 为管理员日志设置30天自动清理
        await adminLogs.createIndex(
            { timestamp: 1 }, 
            { 
                expireAfterSeconds: 30 * 24 * 60 * 60, // 30天
                name: 'auto_cleanup_admin_logs' 
            }
        );
        console.log('✓ 创建TTL索引: 自动清理30天前的管理员日志');
        
        console.log('\n🎉 数据库初始化完成！');
        console.log('\n数据库结构:');
        console.log('1. key_verifications - 密钥验证记录');
        console.log('2. system_stats - 系统统计信息');
        console.log('3. admin_logs - 管理员操作日志');
        console.log('\n索引:');
        console.log('- keyId (唯一索引)');
        console.log('- expiryTime (普通索引 + TTL自动清理)');
        console.log('- createdAt (普通索引)');
        console.log('- deviceInfo.userAgent (普通索引)');
        console.log('- deviceInfo.ipAddress (普通索引)');
        console.log('- admin_logs.timestamp (普通索引 + TTL自动清理)');
        console.log('- admin_logs.action (普通索引)');
        
    } catch (error) {
        console.error('数据库初始化失败:', error);
        process.exit(1);
    } finally {
        if (client) {
            await client.close();
            console.log('数据库连接已关闭');
        }
    }
}

// 如果直接运行此脚本
if (import.meta.url === `file://${process.argv[1]}`) {
    initializeDatabase();
}

export { initializeDatabase };