/**
 * 密钥验证记录数据模型
 * 定义密钥验证记录的数据结构和验证规则
 */

class KeyVerification {
    constructor(data) {
        this.keyId = data.keyId;                    // 密钥唯一标识符
        this.keyType = data.keyType || 'short';     // 密钥类型: 'short' | 'long'
        this.isValid = data.isValid;                // 验证结果: true | false
        this.verificationTime = data.verificationTime || new Date(); // 验证时间
        this.expiryTime = data.expiryTime;          // 密钥过期时间
        this.deviceInfo = data.deviceInfo || {};    // 设备信息
        this.ipAddress = data.ipAddress;            // 客户端IP地址
        this.userAgent = data.userAgent;            // 用户代理字符串
        this.errorMessage = data.errorMessage;      // 验证失败时的错误信息
        this.createdAt = data.createdAt || new Date(); // 记录创建时间
        this.updatedAt = data.updatedAt || new Date(); // 记录更新时间
    }

    /**
     * 验证数据完整性
     */
    validate() {
        const errors = [];

        if (!this.keyId || typeof this.keyId !== 'string') {
            errors.push('keyId is required and must be a string');
        }

        if (this.keyId && this.keyId.length < 10) {
            errors.push('keyId must be at least 10 characters long');
        }

        if (typeof this.isValid !== 'boolean') {
            errors.push('isValid must be a boolean');
        }

        if (!this.verificationTime || !(this.verificationTime instanceof Date)) {
            errors.push('verificationTime must be a valid Date');
        }

        if (this.expiryTime && !(this.expiryTime instanceof Date)) {
            errors.push('expiryTime must be a valid Date');
        }

        if (!this.ipAddress || typeof this.ipAddress !== 'string') {
            errors.push('ipAddress is required and must be a string');
        }

        if (!this.userAgent || typeof this.userAgent !== 'string') {
            errors.push('userAgent is required and must be a string');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * 转换为数据库存储格式
     */
    toDocument() {
        return {
            keyId: this.keyId,
            keyType: this.keyType,
            isValid: this.isValid,
            verificationTime: this.verificationTime,
            expiryTime: this.expiryTime,
            deviceInfo: {
                userAgent: this.userAgent,
                ipAddress: this.ipAddress,
                ...this.deviceInfo
            },
            errorMessage: this.errorMessage,
            createdAt: this.createdAt,
            updatedAt: this.updatedAt
        };
    }

    /**
     * 从数据库文档创建实例
     */
    static fromDocument(doc) {
        return new KeyVerification({
            keyId: doc.keyId,
            keyType: doc.keyType,
            isValid: doc.isValid,
            verificationTime: doc.verificationTime,
            expiryTime: doc.expiryTime,
            deviceInfo: doc.deviceInfo || {},
            ipAddress: doc.deviceInfo?.ipAddress,
            userAgent: doc.deviceInfo?.userAgent,
            errorMessage: doc.errorMessage,
            createdAt: doc.createdAt,
            updatedAt: doc.updatedAt
        });
    }

    /**
     * 检查密钥是否已过期
     */
    isExpired() {
        if (!this.expiryTime) return false;
        return new Date() > this.expiryTime;
    }

    /**
     * 获取密钥剩余有效时间（秒）
     */
    getRemainingTime() {
        if (!this.expiryTime) return null;
        const remaining = Math.floor((this.expiryTime.getTime() - Date.now()) / 1000);
        return Math.max(0, remaining);
    }
}

/**
 * 系统统计数据模型
 */
class SystemStats {
    constructor(data = {}) {
        this._id = data._id || 'global_stats';
        this.totalVerifications = data.totalVerifications || 0;
        this.totalUniqueKeys = data.totalUniqueKeys || 0;
        this.totalFailedAttempts = data.totalFailedAttempts || 0;
        this.lastUpdated = data.lastUpdated || new Date();
        this.createdAt = data.createdAt || new Date();
    }

    toDocument() {
        return {
            _id: this._id,
            totalVerifications: this.totalVerifications,
            totalUniqueKeys: this.totalUniqueKeys,
            totalFailedAttempts: this.totalFailedAttempts,
            lastUpdated: this.lastUpdated,
            createdAt: this.createdAt
        };
    }

    static fromDocument(doc) {
        return new SystemStats(doc);
    }
}

/**
 * 管理员操作日志模型
 */
class AdminLog {
    constructor(data) {
        this.action = data.action;              // 操作类型
        this.adminId = data.adminId;            // 管理员ID
        this.targetKeyId = data.targetKeyId;    // 目标密钥ID（如果适用）
        this.details = data.details || {};     // 操作详情
        this.ipAddress = data.ipAddress;        // 操作IP地址
        this.userAgent = data.userAgent;        // 用户代理
        this.timestamp = data.timestamp || new Date(); // 操作时间
        this.result = data.result;              // 操作结果
    }

    validate() {
        const errors = [];

        if (!this.action || typeof this.action !== 'string') {
            errors.push('action is required and must be a string');
        }

        if (!this.adminId || typeof this.adminId !== 'string') {
            errors.push('adminId is required and must be a string');
        }

        if (!this.ipAddress || typeof this.ipAddress !== 'string') {
            errors.push('ipAddress is required and must be a string');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    toDocument() {
        return {
            action: this.action,
            adminId: this.adminId,
            targetKeyId: this.targetKeyId,
            details: this.details,
            ipAddress: this.ipAddress,
            userAgent: this.userAgent,
            timestamp: this.timestamp,
            result: this.result
        };
    }

    static fromDocument(doc) {
        return new AdminLog(doc);
    }
}

export {
    KeyVerification,
    SystemStats,
    AdminLog
};