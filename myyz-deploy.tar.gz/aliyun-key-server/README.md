# 阿里云密钥管理服务器

## 概述

这是一个专门部署在阿里云服务器上的密钥管理和验证系统。系统采用"一次性密钥"验证机制：
- 如果密钥在数据库中不存在，则验证通过并记录该密钥
- 如果密钥已存在，则验证失败，防止重复使用

## 核心功能

### 🔐 密钥验证
- **唯一性验证**：确保每个密钥只能使用一次
- **自动记录**：验证成功的密钥自动存入数据库
- **IP追踪**：记录使用密钥的IP地址和时间
- **过期机制**：密钥有时效性，过期后自动清理

### 📊 管理功能
- **统计信息**：查看密钥使用统计
- **状态查询**：检查特定密钥的使用状态
- **管理员重置**：管理员可重置特定密钥
- **自动清理**：定期清理过期密钥

### 🛡️ 安全特性
- **API密钥认证**：管理接口需要API密钥
- **速率限制**：防止暴力破解和滥用
- **CORS保护**：限制跨域访问
- **数据加密**：密钥使用SHA256哈希存储

## 部署说明

### 环境要求
- Node.js 18+
- MongoDB 4.4+
- 阿里云ECS服务器

### 安装步骤

1. **安装依赖**
```bash
cd aliyun-key-server
npm install
```

2. **配置环境变量**
```bash
cp .env.example .env
# 编辑 .env 文件，配置数据库连接和安全密钥
```

3. **启动服务**
```bash
# 开发环境
npm run dev

# 生产环境
npm start
```

### 环境变量配置

| 变量名 | 说明 | 默认值 |
|--------|------|--------|
| `PORT` | 服务器端口 | 3003 |
| `MONGODB_URI` | MongoDB连接字符串 | mongodb://localhost:27017 |
| `DATABASE_NAME` | 数据库名称 | aliyun_key_management |
| `API_SECRET_KEY` | API密钥 | 必须设置 |
| `KEY_EXPIRY_HOURS` | 密钥过期时间(小时) | 24 |
| `ALLOWED_ORIGINS` | 允许的跨域来源 | 见配置文件 |

## API接口

### 1. 密钥验证 (核心接口)
```
POST /api/verify-key
Content-Type: application/json

{
  "key": "用户提供的密钥",
  "userAgent": "浏览器信息(可选)",
  "referrer": "来源页面(可选)"
}
```

**响应示例：**
```json
// 验证成功 (密钥首次使用)
{
  "success": true,
  "message": "密钥验证成功",
  "code": "KEY_VERIFIED",
  "keyInfo": {
    "verifiedAt": "2024-01-15T10:30:00.000Z",
    "expiresAt": "2024-01-16T10:30:00.000Z",
    "ip": "192.168.1.100"
  }
}

// 验证失败 (密钥已使用)
{
  "success": false,
  "error": "密钥已被使用，验证失败",
  "code": "KEY_ALREADY_EXISTS",
  "keyInfo": {
    "firstUsedAt": "2024-01-15T08:20:00.000Z",
    "firstUsedIP": "192.168.1.50",
    "totalAttempts": 3
  }
}
```

### 2. 健康检查
```
GET /api/health
```

### 3. 密钥状态查询 (需要API密钥)
```
GET /api/key-status/:key
X-API-Key: your_api_secret_key
```

### 4. 统计信息 (需要API密钥)
```
GET /api/stats
X-API-Key: your_api_secret_key
```

### 5. 管理员重置密钥 (需要API密钥)
```
DELETE /api/reset-key/:key
X-API-Key: your_api_secret_key
```

## 数据库结构

### 密钥记录表 (used_keys)
```javascript
{
  _id: ObjectId,
  key: "原始密钥",
  keyHash: "SHA256哈希值",
  ip: "使用者IP地址",
  userAgent: "浏览器信息",
  referrer: "来源页面",
  createdAt: Date, // 首次使用时间
  expiresAt: Date, // 过期时间
  attemptCount: Number, // 重复尝试次数
  attempts: [{ // 重复尝试记录
    ip: String,
    userAgent: String,
    referrer: String,
    timestamp: Date
  }],
  status: "active" | "expired"
}
```

### 索引
- `keyHash`: 唯一索引，确保密钥唯一性
- `ip`: 普通索引，用于IP查询
- `createdAt`: 普通索引，用于时间查询
- `expiresAt`: TTL索引，自动清理过期记录

## 安全考虑

1. **密钥存储**：原始密钥使用SHA256哈希存储
2. **API保护**：管理接口需要API密钥认证
3. **速率限制**：防止暴力破解
4. **CORS限制**：只允许指定域名访问
5. **输入验证**：严格验证所有输入参数
6. **错误处理**：不泄露敏感信息

## 监控和维护

- **自动清理**：每小时自动清理过期密钥
- **日志记录**：详细记录所有操作
- **健康检查**：提供服务状态检查接口
- **统计监控**：实时统计密钥使用情况

## 注意事项

⚠️ **重要提醒**：
- 此服务器代码仅用于阿里云部署，不应上传到公共Git仓库
- 生产环境必须配置强密码和API密钥
- 建议配置防火墙，只允许必要的端口访问
- 定期备份MongoDB数据库
- 监控服务器资源使用情况