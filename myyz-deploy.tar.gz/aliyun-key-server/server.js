import express from 'express';
import cors from 'cors';
import crypto from 'crypto';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { body, validationResult } from 'express-validator';
import compression from 'compression';
import dotenv from 'dotenv';
import DatabaseService from './services/DatabaseService.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3003;

// 安全中间件
app.use(helmet());
app.use(compression());

// CORS配置
const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || [
    'https://myyz.vercel.app',
    'https://myyz-git-main-a1234s-projects.vercel.app',
    'http://localhost:3000',
    'http://localhost:8000'
];

app.use(cors({
    origin: allowedOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key']
}));

// 速率限制
const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15分钟
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // 限制每个IP 100次请求
    message: {
        error: '请求过于频繁，请稍后再试',
        code: 'RATE_LIMIT_EXCEEDED'
    }
});

app.use('/api/', limiter);
app.use(express.json({ limit: '10mb' }));

// 数据库服务
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/aliyun-key-management';
const dbService = new DatabaseService(MONGODB_URI);

// 工具函数
function generateSecureHash(data) {
    return crypto.createHash('sha256').update(data).digest('hex');
}

function getClientIP(req) {
    return req.headers['x-forwarded-for'] || 
           req.headers['x-real-ip'] || 
           req.connection.remoteAddress || 
           req.socket.remoteAddress ||
           (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
           req.ip;
}

function validateAPIKey(req, res, next) {
    const apiKey = req.headers['x-api-key'];
    const expectedKey = process.env.API_SECRET_KEY;
    
    if (!apiKey || !expectedKey || apiKey !== expectedKey) {
        return res.status(401).json({
            success: false,
            error: '无效的API密钥',
            code: 'INVALID_API_KEY'
        });
    }
    
    next();
}

// API路由

// 健康检查
app.get('/api/health', async (req, res) => {
    try {
        const dbHealth = await dbService.getHealthStatus();
        res.json({
            status: 'healthy',
            timestamp: new Date().toISOString(),
            database: dbHealth
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            timestamp: new Date().toISOString(),
            database: { status: 'error', message: error.message }
        });
    }
});

// 密钥验证接口 - 核心功能
app.post('/api/verify-key', [
    body('key').isString().isLength({ min: 1, max: 100 }).trim(),
    body('userAgent').optional().isString(),
    body('referrer').optional().isString()
], async (req, res) => {
    try {
        // 验证输入
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                error: '输入参数无效',
                details: errors.array(),
                code: 'INVALID_INPUT'
            });
        }

        const { key, userAgent, referrer } = req.body;
        const clientIP = getClientIP(req);
        const keyHash = generateSecureHash(key);
        
        console.log(`🔍 密钥验证请求: IP=${clientIP}, Key=${key.substring(0, 8)}...`);

        // 使用数据库服务验证密钥
        const result = await dbService.verifyAndRecordKey({
            keyId: key,
            keyType: 'short', // 根据实际需要调整
            isValid: true, // 这里可以添加实际的密钥格式验证逻辑
            verificationTime: new Date(),
            expiryTime: new Date(Date.now() + (parseInt(process.env.KEY_EXPIRY_HOURS) || 24) * 60 * 60 * 1000),
            ipAddress: clientIP,
            userAgent: userAgent || req.get('User-Agent'),
            deviceInfo: {
                referrer: referrer
            }
        });

        if (result.success) {
            console.log(`✅ 新密钥验证成功: ${key.substring(0, 8)}...`);
            
            res.json({
                success: true,
                message: result.message,
                code: 'KEY_VERIFIED',
                keyInfo: {
                    verifiedAt: result.verificationTime,
                    expiresAt: result.expiryTime,
                    ip: clientIP
                }
            });
        } else {
            console.log(`❌ 密钥验证失败: ${key.substring(0, 8)}... - ${result.message}`);
            
            res.status(409).json({
                success: false,
                error: result.message,
                code: 'KEY_ALREADY_EXISTS',
                keyInfo: {
                    firstUsedAt: result.firstUsedAt,
                    isExpired: result.isExpired
                }
            });
        }

    } catch (error) {
        console.error('❌ 密钥验证失败:', error);
        res.status(500).json({
            success: false,
            error: '服务器内部错误',
            code: 'INTERNAL_ERROR'
        });
    }
});

// 查询密钥状态
app.get('/api/key-status/:key', validateAPIKey, async (req, res) => {
    try {
        const { key } = req.params;
        
        const keyRecord = await dbService.getKeyStatus(key);
        
        if (!keyRecord) {
            return res.json({
                success: true,
                exists: false,
                message: '密钥未被使用'
            });
        }
        
        res.json({
            success: true,
            exists: true,
            keyInfo: {
                createdAt: keyRecord.createdAt,
                expiresAt: keyRecord.expiryTime,
                ip: keyRecord.ipAddress,
                isExpired: keyRecord.isExpired(),
                remainingTime: keyRecord.getRemainingTime(),
                status: keyRecord.isExpired() ? 'expired' : 'active'
            }
        });
        
    } catch (error) {
        console.error('❌ 查询密钥状态错误:', error);
        res.status(500).json({
            success: false,
            error: '服务器内部错误'
        });
    }
});

// 获取密钥统计信息
app.get('/api/stats', validateAPIKey, async (req, res) => {
    try {
        const stats = await dbService.getSystemStats();
        
        res.json({
            success: true,
            stats: {
                totalKeys: stats.totalUniqueKeys,
                totalVerifications: stats.totalVerifications,
                failedAttempts: stats.totalFailedAttempts,
                successRate: stats.totalVerifications > 0 ? 
                    ((stats.totalVerifications - stats.totalFailedAttempts) / stats.totalVerifications * 100).toFixed(2) + '%' : 
                    '0%'
            },
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('❌ 获取统计信息错误:', error);
        res.status(500).json({
            success: false,
            error: '服务器内部错误'
        });
    }
});

// 清理过期密钥
app.delete('/api/cleanup-expired', validateAPIKey, async (req, res) => {
    try {
        const result = await dbService.cleanupExpiredKeys();
        
        console.log(`🧹 清理了 ${result.deletedCount} 个过期密钥`);
        
        res.json({
            success: true,
            message: `成功清理 ${result.deletedCount} 个过期密钥`,
            deletedCount: result.deletedCount
        });
        
    } catch (error) {
        console.error('❌ 清理过期密钥错误:', error);
        res.status(500).json({
            success: false,
            error: '服务器内部错误'
        });
    }
});

// 管理员重置密钥
app.delete('/api/reset-key/:key', validateAPIKey, async (req, res) => {
    try {
        const { key } = req.params;
        const clientIP = getClientIP(req);
        const userAgent = req.get('User-Agent');
        
        const result = await dbService.adminResetKey(key, {
            adminId: 'api-admin', // 可以从认证中获取实际管理员ID
            ipAddress: clientIP,
            userAgent: userAgent
        });
        
        if (!result.success) {
            return res.status(404).json({
                success: false,
                error: result.message
            });
        }
        
        console.log(`🔄 管理员重置密钥: ${key.substring(0, 8)}...`);
        
        res.json({
            success: true,
            message: result.message
        });
        
    } catch (error) {
        console.error('❌ 重置密钥错误:', error);
        res.status(500).json({
            success: false,
            error: '服务器内部错误'
        });
    }
});

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error('❌ 未处理的错误:', err);
    res.status(500).json({
        success: false,
        error: '服务器内部错误',
        code: 'INTERNAL_ERROR'
    });
});

// 404处理
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: '接口不存在',
        code: 'NOT_FOUND'
    });
});

// 启动服务器
async function startServer() {
    try {
        await dbService.connect();
        
        app.listen(PORT, () => {
            console.log(`🚀 阿里云密钥管理服务器启动成功`);
            console.log(`📡 服务器地址: http://localhost:${PORT}`);
            console.log(`🔒 环境: ${process.env.NODE_ENV || 'development'}`);
            console.log(`📊 数据库: MongoDB 连接成功`);
        });
        
        // 定期清理过期密钥
        setInterval(async () => {
            try {
                const result = await dbService.cleanupExpiredKeys();
                if (result.deletedCount > 0) {
                    console.log(`🧹 自动清理了 ${result.deletedCount} 个过期密钥`);
                }
            } catch (error) {
                console.error('❌ 自动清理错误:', error);
            }
        }, 60 * 60 * 1000); // 每小时清理一次
        
    } catch (error) {
        console.error('❌ 服务器启动失败:', error);
        process.exit(1);
    }
}

// 优雅关闭
process.on('SIGINT', async () => {
    console.log('\n🛑 收到中断信号，正在优雅关闭服务器...');
    try {
        await dbService.disconnect();
        console.log('✅ 数据库连接已关闭');
    } catch (error) {
        console.error('❌ 关闭数据库连接时出错:', error);
    }
    process.exit(0);
});

process.on('SIGTERM', async () => {
    console.log('\n🛑 收到终止信号，正在优雅关闭服务器...');
    try {
        await dbService.disconnect();
        console.log('✅ 数据库连接已关闭');
    } catch (error) {
        console.error('❌ 关闭数据库连接时出错:', error);
    }
    process.exit(0);
});

startServer();